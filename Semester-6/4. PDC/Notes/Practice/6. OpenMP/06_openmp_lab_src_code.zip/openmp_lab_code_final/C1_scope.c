/*
 * OpenMP Lab Code Bundle (FINAL) - CS-3006
 * Build: gcc -O2 -fopenmp file.c -o prog
 * Run:   export OMP_NUM_THREADS=4; ./prog
 * Optional stable binding:
 *   export OMP_PROC_BIND=true
 *   export OMP_PLACES=cores
 *
 * Timing: omp_get_wtime()
 */


#include <stdio.h>
#include <omp.h>

int main() {
    int x = 10;

    double t0 = omp_get_wtime();

    #pragma omp parallel private(x)
    {
        x = 100 + omp_get_thread_num();
    }

    double t1 = omp_get_wtime();
    printf("After parallel region, x = %d\n", x);
    printf("Time=%.6f s\n", t1 - t0);
    return 0;
}
