/*
 * OpenMP Lab Code Bundle (FINAL) - CS-3006
 * Build: gcc -O2 -fopenmp file.c -o prog
 * Run:   export OMP_NUM_THREADS=4; ./prog
 * Optional stable binding:
 *   export OMP_PROC_BIND=true
 *   export OMP_PLACES=cores
 *
 * Timing: omp_get_wtime()
 */


#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

static void init(double *A, double *x, int N) {
    for (int i = 0; i < N; i++) x[i] = 1.0 / (1.0 + i);
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            A[(size_t)i*N + j] = (double)((i + 1) * (j + 1)) / (double)N;
}

static double checksum(const double *y, int N) {
    double s = 0.0;
    int step = (N/10 ? N/10 : 1);
    for (int i = 0; i < N; i += step) s += y[i];
    return s;
}

static double matvec_serial(const double *A, const double *x, double *y, int N) {
    double t0 = omp_get_wtime();
    for (int i = 0; i < N; i++) {
        double sum = 0.0;
        const double *row = &A[(size_t)i*N];
        for (int j = 0; j < N; j++) sum += row[j] * x[j];
        y[i] = sum;
    }
    return omp_get_wtime() - t0;
}

static double matvec_omp(const double *A, const double *x, double *y, int N, int threads) {
    omp_set_num_threads(threads);
    double t0 = omp_get_wtime();

    #pragma omp parallel for
    for (int i = 0; i < N; i++) {
        double sum = 0.0;
        const double *row = &A[(size_t)i*N];
        for (int j = 0; j < N; j++) sum += row[j] * x[j];
        y[i] = sum;
    }

    return omp_get_wtime() - t0;
}

int main(int argc, char **argv) {
    int N = 2048;
    int repeats = 3;
    if (argc >= 2) N = atoi(argv[1]);
    if (argc >= 3) repeats = atoi(argv[2]);

    if (N <= 0 || repeats <= 0) {
        fprintf(stderr, "Usage: %s [N] [repeats]\n", argv[0]);
        return 1;
    }

    size_t bytesA = (size_t)N * (size_t)N * sizeof(double);
    size_t bytesX = (size_t)N * sizeof(double);
    size_t bytesY = (size_t)N * sizeof(double);

    size_t padA = (bytesA + 63) & ~((size_t)63);
    size_t padX = (bytesX + 63) & ~((size_t)63);
    size_t padY = (bytesY + 63) & ~((size_t)63);

    double *A = (double*) aligned_alloc(64, padA);
    double *x = (double*) aligned_alloc(64, padX);
    double *y = (double*) aligned_alloc(64, padY);
    if (!A || !x || !y) { fprintf(stderr, "alloc failed (try smaller N)\n"); return 1; }

    init(A, x, N);

    matvec_serial(A, x, y, N); // warmup

    double T1 = 1e9;
    for (int r = 0; r < repeats; r++) {
        double t = matvec_serial(A, x, y, N);
        if (t < T1) T1 = t;
    }
    double chk1 = checksum(y, N);
    double flops = 2.0 * (double)N * (double)N;

    printf("MatVec Benchmark\n");
    printf("N=%d repeats=%d\n", N, repeats);
    printf("T1 (serial best)=%.6f s  GFLOP/s=%.3f  checksum=%.6f\n",
           T1, (T1>0 ? flops/T1/1e9 : 0.0), chk1);

    printf("\n%-10s %-12s %-10s %-12s %-10s\n", "Threads", "Time(s)", "Speedup", "Efficiency", "GFLOP/s");
    printf("--------------------------------------------------------------\n");

    int maxT = omp_get_max_threads();
    int candidates[] = {1,2,4,8,16,32,64};

    for (int ci = 0; ci < (int)(sizeof(candidates)/sizeof(candidates[0])); ci++) {
        int P = candidates[ci];
        if (P > maxT) continue;

        matvec_omp(A, x, y, N, P); // warmup

        double Tp = 1e9;
        for (int r = 0; r < repeats; r++) {
            double t = matvec_omp(A, x, y, N, P);
            if (t < Tp) Tp = t;
        }

        double chk = checksum(y, N);
        double speedup = (Tp > 0) ? (T1 / Tp) : 0.0;
        double eff     = (P > 0) ? (speedup / (double)P) : 0.0;
        double gflops  = (Tp > 0) ? (flops / Tp / 1e9) : 0.0;
        double relerr  = (chk1 != 0.0) ? ((chk - chk1) / chk1) : 0.0;

        printf("%-10d %-12.6f %-10.3f %-12.3f %-10.3f   (relerr=%.3e)\n",
               P, Tp, speedup, eff, gflops, relerr);
    }

    free(A); free(x); free(y);
    return 0;
}
