/*
 * OpenMP Lab Code Bundle (FINAL) - CS-3006
 * Build: gcc -O2 -fopenmp file.c -o prog
 * Run:   export OMP_NUM_THREADS=4; ./prog
 * Optional stable binding:
 *   export OMP_PROC_BIND=true
 *   export OMP_PLACES=cores
 *
 * Timing: omp_get_wtime()
 */


#include <stdio.h>
#include <omp.h>

int main() {
    const int N = 50000000;
    long sum = 0;

    double t0 = omp_get_wtime();

    #pragma omp parallel for
    for (int i = 0; i < N; i++) {
        #pragma omp critical
        sum++;
    }

    double t1 = omp_get_wtime();
    double dt = t1 - t0;
    printf("N=%d sum=%ld Time=%.6f s\n", N, sum, dt);
    if (dt > 0) printf("Throughput: %.2f Mops/s\n", (double)N/dt/1e6);
    return 0;
}
