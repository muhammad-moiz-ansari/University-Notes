/*
 * OpenMP Lab Code Bundle (FINAL) - CS-3006
 * Build: gcc -O2 -fopenmp file.c -o prog
 * Run:   export OMP_NUM_THREADS=4; ./prog
 * Optional stable binding:
 *   export OMP_PROC_BIND=true
 *   export OMP_PLACES=cores
 *
 * Timing: omp_get_wtime()
 */


#include <stdio.h>
#include <omp.h>

int main() {
    const long N = 200000000L;
    static double partial[256];

    double t0 = omp_get_wtime();

    #pragma omp parallel
    {
        int tid = omp_get_thread_num();
        for (long i = 0; i < N; i++) partial[tid] += 1.0;
    }

    double t1 = omp_get_wtime();
    double dt = t1 - t0;
    int P = omp_get_max_threads();
    double updates = (double)N * (double)P;
    printf("Threads(max)=%d Time(no padding)=%.6f s  Updates/s=%.3e\n",
           P, dt, dt>0 ? updates/dt : 0.0);
    return 0;
}
