/*
 * OpenMP Lab Code Bundle (FINAL) - CS-3006
 * Build: gcc -O2 -fopenmp file.c -o prog
 * Run:   export OMP_NUM_THREADS=4; ./prog
 * Optional stable binding:
 *   export OMP_PROC_BIND=true
 *   export OMP_PLACES=cores
 *
 * Timing: omp_get_wtime()
 */


#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main() {
    const int N = 1<<20;
    int *A = (int*) malloc((size_t)N * sizeof(int));
    if (!A) { fprintf(stderr, "alloc failed\n"); return 1; }

    int expected = 1234567;
    for (int i = 0; i < N; i++) A[i] = (i * 37) % 1000000;
    A[N/2] = expected;

    int mx = -1;

    double t0 = omp_get_wtime();

    #pragma omp parallel for reduction(max:mx)
    for (int i = 0; i < N; i++) {
        if (A[i] > mx) mx = A[i];
    }

    double t1 = omp_get_wtime();
    printf("max = %d (expected %d)\n", mx, expected);
    printf("Time=%.6f s  Throughput=%.2f Mitems/s\n", t1 - t0, (double)N/(t1-t0)/1e6);

    free(A);
    return 0;
}
