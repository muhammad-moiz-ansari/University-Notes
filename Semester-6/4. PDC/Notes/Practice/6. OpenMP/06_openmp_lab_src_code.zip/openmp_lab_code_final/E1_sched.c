/*
 * OpenMP Lab Code Bundle (FINAL) - CS-3006
 * Build: gcc -O2 -fopenmp file.c -o prog
 * Run:   export OMP_NUM_THREADS=4; ./prog
 * Optional stable binding:
 *   export OMP_PROC_BIND=true
 *   export OMP_PLACES=cores
 *
 * Timing: omp_get_wtime()
 */


#include <stdio.h>
#include <omp.h>

static inline void heavy_work(int i) {
    volatile long sink = 0;
    long iters = (long)i * 2000L;
    for (long j = 0; j < iters; j++) sink += j;
}

int main() {
    const int N = 20000;
    double t0 = omp_get_wtime();

    #pragma omp parallel for schedule(static)
    for (int i = 0; i < N; i++) heavy_work(i);

    double t1 = omp_get_wtime();
    printf("N=%d Time=%.6f s\n", N, t1 - t0);
    return 0;
}
