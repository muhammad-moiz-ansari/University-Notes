/*
 * OpenMP Lab Code Bundle (FINAL) - CS-3006
 * Build: gcc -O2 -fopenmp file.c -o prog
 * Run:   export OMP_NUM_THREADS=4; ./prog
 * Optional stable binding:
 *   export OMP_PROC_BIND=true
 *   export OMP_PLACES=cores
 *
 * Timing: omp_get_wtime()
 */


#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(int argc, char **argv) {
    int R = 2048, C = 2048;
    if (argc >= 3) { R = atoi(argv[1]); C = atoi(argv[2]); }

    size_t N = (size_t)R * (size_t)C;
    double *A = (double*) malloc(N * sizeof(double));
    double *B = (double*) malloc(N * sizeof(double));
    if (!A || !B) { fprintf(stderr, "alloc failed\n"); return 1; }

    for (size_t i = 0; i < N; i++) A[i] = (double)(i % 1000) * 0.001;

    double t0 = omp_get_wtime();

    #pragma omp parallel for collapse(2)
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            size_t idx = (size_t)i * (size_t)C + (size_t)j;
            B[idx] = A[idx] + 1.0;
        }
    }

    double t1 = omp_get_wtime();
    double chk = 0.0;
    for (size_t k = 0; k < N; k += (N/10 ? N/10 : 1)) chk += B[k];

    printf("R=%d C=%d Time=%.6f s  Throughput=%.2f Melems/s  checksum=%.3f\n",
           R, C, t1 - t0, (double)N/(t1-t0)/1e6, chk);

    free(A); free(B);
    return 0;
}
