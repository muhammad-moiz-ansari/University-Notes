/*
 * OpenMP Lab Code Bundle (FINAL) - CS-3006
 * Build: gcc -O2 -fopenmp file.c -o prog
 * Run:   export OMP_NUM_THREADS=4; ./prog
 * Optional stable binding:
 *   export OMP_PROC_BIND=true
 *   export OMP_PLACES=cores
 *
 * Timing: omp_get_wtime()
 */


#include <stdio.h>
#include <omp.h>

int main() {
    const int N = 20;
    int A[20];
    int sum = 0;

    for (int i = 0; i < N; i++) A[i] = i + 1;

    double t0 = omp_get_wtime();

    #pragma omp parallel default(none) shared(A, N) reduction(+:sum)
    {
        #pragma omp for
        for (int i = 0; i < N; i++) sum += A[i];
    }

    double t1 = omp_get_wtime();
    printf("Sum = %d\n", sum);
    printf("Time=%.6f s\n", t1 - t0);
    return 0;
}
