/*
 * OpenMP Lab Code Bundle (FINAL) - CS-3006
 * Build: gcc -O2 -fopenmp file.c -o prog
 * Run:   export OMP_NUM_THREADS=4; ./prog
 * Optional stable binding:
 *   export OMP_PROC_BIND=true
 *   export OMP_PLACES=cores
 *
 * Timing: omp_get_wtime()
 */


#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main() {
    const int N = 20000000;
    double *A = (double*) malloc((size_t)N * sizeof(double));
    double *B = (double*) malloc((size_t)N * sizeof(double));
    if (!A || !B) { fprintf(stderr, "alloc failed\n"); return 1; }

    double t0 = omp_get_wtime();

    #pragma omp parallel
    {
        #pragma omp for nowait
        for (int i = 0; i < N; i++) A[i] = i * 0.5;

        #pragma omp barrier

        #pragma omp for
        for (int i = 0; i < N; i++) B[i] = A[i] + 1.0;
    }

    double t1 = omp_get_wtime();
    double chk = 0.0;
    for (int i = 0; i < N; i += (N/10 ? N/10 : 1)) chk += B[i];

    printf("Time=%.6f s  Checksum=%.3f  (explicit barrier)\n", t1 - t0, chk);

    free(A); free(B);
    return 0;
}
