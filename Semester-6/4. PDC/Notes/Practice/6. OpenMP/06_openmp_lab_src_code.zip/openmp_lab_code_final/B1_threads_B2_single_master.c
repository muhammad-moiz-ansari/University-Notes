/*
 * OpenMP Lab Code Bundle (FINAL) - CS-3006
 * Build: gcc -O2 -fopenmp file.c -o prog
 * Run:   export OMP_NUM_THREADS=4; ./prog
 * Optional stable binding:
 *   export OMP_PROC_BIND=true
 *   export OMP_PLACES=cores
 *
 * Timing: omp_get_wtime()
 */


#include <stdio.h>
#include <omp.h>

int main() {
    omp_set_num_threads(2);

    double t0 = omp_get_wtime();

    #pragma omp parallel if(1) num_threads(4)
    {
        int tid = omp_get_thread_num();
        int P   = omp_get_num_threads();

        #pragma omp critical
        printf("[B1] Hello from T=%d (team size=%d)\n", tid, P);

        #pragma omp single
        printf("[B2] single prints once. Executed by tid=%d. (implicit barrier at end)\n",
               omp_get_thread_num());

        #pragma omp master
        printf("[B2] master prints once. Executed by tid=%d. (NO implicit barrier)\n",
               omp_get_thread_num());
    }

    double t1 = omp_get_wtime();
    printf("Time=%.6f s\n", t1 - t0);
    return 0;
}
