// v1_axpy_scalar.c
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>

static inline double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

static void init_arrays(float *x, float *y, size_t N) {
    for (size_t i = 0; i < N; i++) {
        x[i] = (float)(0.001 * (double)(i % 1000));
        y[i] = (float)(0.002 * (double)((i + 7) % 1000));
    }
}

static float checksum(const float *y, size_t N) {
    double s = 0.0;
    for (size_t i = 0; i < N; i += (N/16 + 1)) s += y[i];
    return (float)s;
}

static void axpy_scalar(float *y, const float *x, float a, size_t N) {
    for (size_t i = 0; i < N; i++) {
        y[i] = a * x[i] + y[i];
    }
}

int main(int argc, char **argv) {
    size_t N = (argc > 1) ? (size_t)atoll(argv[1]) : (size_t)16 * 1024 * 1024;
    int R = (argc > 2) ? atoi(argv[2]) : 10;
    float a = (argc > 3) ? (float)atof(argv[3]) : 1.2345f;

    float *x = (float*)malloc(N * sizeof(float));
    float *y = (float*)malloc(N * sizeof(float));
    if (!x || !y) { fprintf(stderr, "alloc failed\n"); return 1; }

    init_arrays(x, y, N);

    // warmup
    axpy_scalar(y, x, a, N);

    double t0 = now_sec();
    for (int r = 0; r < R; r++) axpy_scalar(y, x, a, N);
    double t1 = now_sec();

    double sec = t1 - t0;
    double bytes = 12.0 * (double)N * (double)R; // ~12 bytes per element
    double gbps = (bytes / sec) / 1e9;

    printf("Variant 1 (Scalar)  N=%zu R=%d  time=%.6f s  BW~%.2f GB/s  checksum=%f\n",
           N, R, sec, gbps, checksum(y, N));

    free(x); free(y);
    return 0;
}
