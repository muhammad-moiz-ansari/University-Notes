// v5_axpy_simd_unroll4.c
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <immintrin.h>

static inline double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

static void init_arrays(float *x, float *y, size_t N) {
    for (size_t i = 0; i < N; i++) {
        x[i] = (float)(0.001 * (double)(i % 1000));
        y[i] = (float)(0.002 * (double)((i + 7) % 1000));
    }
}

static float checksum(const float *y, size_t N) {
    double s = 0.0;
    for (size_t i = 0; i < N; i += (N/16 + 1)) s += y[i];
    return (float)s;
}

static void axpy_simd_unroll4(float * restrict y,
                              const float * restrict x,
                              float a, size_t N)
{
    __m256 va = _mm256_set1_ps(a);
    size_t i = 0;
    size_t limit = N & ~(size_t)31; // multiple of 32 floats

    for (; i < limit; i += 32) {
        __m256 x0 = _mm256_loadu_ps(x + i + 0);
        __m256 y0 = _mm256_loadu_ps(y + i + 0);
        __m256 x1 = _mm256_loadu_ps(x + i + 8);
        __m256 y1 = _mm256_loadu_ps(y + i + 8);
        __m256 x2 = _mm256_loadu_ps(x + i + 16);
        __m256 y2 = _mm256_loadu_ps(y + i + 16);
        __m256 x3 = _mm256_loadu_ps(x + i + 24);
        __m256 y3 = _mm256_loadu_ps(y + i + 24);

        y0 = _mm256_fmadd_ps(va, x0, y0);
        y1 = _mm256_fmadd_ps(va, x1, y1);
        y2 = _mm256_fmadd_ps(va, x2, y2);
        y3 = _mm256_fmadd_ps(va, x3, y3);

        _mm256_storeu_ps(y + i + 0,  y0);
        _mm256_storeu_ps(y + i + 8,  y1);
        _mm256_storeu_ps(y + i + 16, y2);
        _mm256_storeu_ps(y + i + 24, y3);
    }

    // leftover: do 8-wide then scalar tail
    size_t limit8 = N & ~(size_t)7;
    for (; i < limit8; i += 8) {
        __m256 vx = _mm256_loadu_ps(x + i);
        __m256 vy = _mm256_loadu_ps(y + i);
        __m256 vout = _mm256_fmadd_ps(va, vx, vy);
        _mm256_storeu_ps(y + i, vout);
    }
    for (; i < N; i++) y[i] = a * x[i] + y[i];
}

int main(int argc, char **argv) {
    size_t N = (argc > 1) ? (size_t)atoll(argv[1]) : (size_t)16 * 1024 * 1024;
    int R = (argc > 2) ? atoi(argv[2]) : 10;
    float a = (argc > 3) ? (float)atof(argv[3]) : 1.2345f;

    float *x = (float*)malloc(N * sizeof(float));
    float *y = (float*)malloc(N * sizeof(float));
    if (!x || !y) { fprintf(stderr, "alloc failed\n"); return 1; }

    init_arrays(x, y, N);
    axpy_simd_unroll4(y, x, a, N); // warmup

    double t0 = now_sec();
    for (int r = 0; r < R; r++) axpy_simd_unroll4(y, x, a, N);
    double t1 = now_sec();

    double sec = t1 - t0;
    double bytes = 12.0 * (double)N * (double)R;
    double gbps = (bytes / sec) / 1e9;

    printf("Variant 5 (SIMD + unroll4)  N=%zu R=%d  time=%.6f s  BW~%.2f GB/s  checksum=%f\n",
           N, R, sec, gbps, checksum(y, N));

    free(x); free(y);
    return 0;
}
