// v7_axpy_pthreads_simd.c
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <pthread.h>
#include <immintrin.h>
#ifdef __linux__
#include <sched.h>
#endif

static inline double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

static void init_arrays(float *x, float *y, size_t N) {
    for (size_t i = 0; i < N; i++) {
        x[i] = (float)(0.001 * (double)(i % 1000));
        y[i] = (float)(0.002 * (double)((i + 7) % 1000));
    }
}

static float checksum(const float *y, size_t N) {
    double s = 0.0;
    for (size_t i = 0; i < N; i += (N/16 + 1)) s += y[i];
    return (float)s;
}

// Best kernel: Variant 5 style (unroll4)
static void axpy_simd_unroll4_chunk(float * restrict y,
                                    const float * restrict x,
                                    float a, size_t begin, size_t end)
{
    __m256 va = _mm256_set1_ps(a);

    size_t i = begin;
    size_t len = end - begin;

    // Make sure we don't run past end; unrolled loop needs 32-float blocks
    size_t limit = begin + (len & ~(size_t)31);

    for (; i < limit; i += 32) {
        __m256 x0 = _mm256_loadu_ps(x + i + 0);
        __m256 y0 = _mm256_loadu_ps(y + i + 0);
        __m256 x1 = _mm256_loadu_ps(x + i + 8);
        __m256 y1 = _mm256_loadu_ps(y + i + 8);
        __m256 x2 = _mm256_loadu_ps(x + i + 16);
        __m256 y2 = _mm256_loadu_ps(y + i + 16);
        __m256 x3 = _mm256_loadu_ps(x + i + 24);
        __m256 y3 = _mm256_loadu_ps(y + i + 24);

        y0 = _mm256_fmadd_ps(va, x0, y0);
        y1 = _mm256_fmadd_ps(va, x1, y1);
        y2 = _mm256_fmadd_ps(va, x2, y2);
        y3 = _mm256_fmadd_ps(va, x3, y3);

        _mm256_storeu_ps(y + i + 0,  y0);
        _mm256_storeu_ps(y + i + 8,  y1);
        _mm256_storeu_ps(y + i + 16, y2);
        _mm256_storeu_ps(y + i + 24, y3);
    }

    size_t limit8 = begin + (len & ~(size_t)7);
    for (; i < limit8; i += 8) {
        __m256 vx = _mm256_loadu_ps(x + i);
        __m256 vy = _mm256_loadu_ps(y + i);
        __m256 vout = _mm256_fmadd_ps(va, vx, vy);
        _mm256_storeu_ps(y + i, vout);
    }
    for (; i < end; i++) y[i] = a * x[i] + y[i];
}

typedef struct {
    float *y;
    const float *x;
    float a;
    size_t begin;
    size_t end;
    int tid;
    int pin; // 1 = pin threads if linux
} task_t;

static void *worker(void *arg) {
    task_t *t = (task_t*)arg;

#ifdef __linux__
    if (t->pin) {
        cpu_set_t set;
        CPU_ZERO(&set);
        CPU_SET(t->tid, &set);
        pthread_setaffinity_np(pthread_self(), sizeof(set), &set);
    }
#endif

    axpy_simd_unroll4_chunk(t->y, t->x, t->a, t->begin, t->end);
    return NULL;
}

int main(int argc, char **argv) {
    size_t N = (argc > 1) ? (size_t)atoll(argv[1]) : (size_t)16 * 1024 * 1024;
    int R = (argc > 2) ? atoi(argv[2]) : 10;
    float a = (argc > 3) ? (float)atof(argv[3]) : 1.2345f;
    int T = (argc > 4) ? atoi(argv[4]) : 4;
    int pin = (argc > 5) ? atoi(argv[5]) : 0;

    float *x = (float*)malloc(N * sizeof(float));
    float *y = (float*)malloc(N * sizeof(float));
    if (!x || !y) { fprintf(stderr, "alloc failed\n"); return 1; }

    init_arrays(x, y, N);

    // Warmup single-thread chunk to prime pages/cache
    axpy_simd_unroll4_chunk(y, x, a, 0, N);

    pthread_t *threads = (pthread_t*)malloc((size_t)T * sizeof(pthread_t));
    task_t *tasks = (task_t*)malloc((size_t)T * sizeof(task_t));
    if (!threads || !tasks) return 1;

    double t0 = now_sec();
    for (int r = 0; r < R; r++) {
        size_t chunk = N / (size_t)T;
        size_t start = 0;
        for (int t = 0; t < T; t++) {
            size_t end = (t == T - 1) ? N : (start + chunk);

            // Make chunk boundaries nicer for SIMD (optional hygiene):
            // round end down to multiple of 8, except last thread.
            if (t != T - 1) end &= ~(size_t)7;

            tasks[t] = (task_t){ .y=y, .x=x, .a=a, .begin=start, .end=end, .tid=t, .pin=pin };
            pthread_create(&threads[t], NULL, worker, &tasks[t]);
            start = end;
        }
        for (int t = 0; t < T; t++) pthread_join(threads[t], NULL);
    }
    double t1 = now_sec();

    double sec = t1 - t0;
    double bytes = 12.0 * (double)N * (double)R;
    double gbps = (bytes / sec) / 1e9;

    printf("Variant 7 (Pthreads+SIMD)  N=%zu R=%d T=%d pin=%d  time=%.6f s  BW~%.2f GB/s  checksum=%f\n",
           N, R, T, pin, sec, gbps, checksum(y, N));

    free(threads); free(tasks);
    free(x); free(y);
    return 0;
}
