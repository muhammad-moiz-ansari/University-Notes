#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>

// A simple macro for checking CUDA API calls
#define CHECK_CUDA_ERROR(val) check((val), #val, __FILE__, __LINE__)

void check(cudaError_t result, char const *const func, const char *const file, int const line) {
    if (result) {
        fprintf(stderr, "CUDA error at %s:%d code=%d(%s) \"%s\" \n", file, line, static_cast<unsigned int>(result), cudaGetErrorName(result), func);
        exit(EXIT_FAILURE);
    }
}

// The CPU function for comparison
void add_cpu(int* a, int* b, int* c) {
    *c = *a + *b;
}

// The GPU kernel function
__global__ void add_gpu(int *d_a, int *d_b, int *d_c) {
    *d_c = *d_a + *d_b;
}

int main() {
    int a = 5, b = 7, c_cpu, c_gpu; // Host variables
    int *d_a, *d_b, *d_c; // Device pointers

    // Allocate memory on the GPU
    CHECK_CUDA_ERROR(cudaMalloc((void **)&d_a, sizeof(int)));
    CHECK_CUDA_ERROR(cudaMalloc((void **)&d_b, sizeof(int)));
    CHECK_CUDA_ERROR(cudaMalloc((void **)&d_c, sizeof(int)));

    // Copy data from host to device
    CHECK_CUDA_ERROR(cudaMemcpy(d_a, &a, sizeof(int), cudaMemcpyHostToDevice));
    CHECK_CUDA_ERROR(cudaMemcpy(d_b, &b, sizeof(int), cudaMemcpyHostToDevice));

    // Launch GPU kernel
    add_gpu<<<1, 1>>>(d_a, d_b, d_c);

    // Check for errors from the asynchronous kernel launch
    CHECK_CUDA_ERROR(cudaGetLastError());

    // Synchronize to ensure kernel completion before copying back
    CHECK_CUDA_ERROR(cudaDeviceSynchronize());

    // Copy result back to host
    CHECK_CUDA_ERROR(cudaMemcpy(&c_gpu, d_c, sizeof(int), cudaMemcpyDeviceToHost));

    // Perform addition on CPU
    add_cpu(&a, &b, &c_cpu);

    printf("Sum on CPU: %d\n", c_cpu);
    printf("Sum on GPU: %d\n", c_gpu);

    // Free device memory
    CHECK_CUDA_ERROR(cudaFree(d_a));
    CHECK_CUDA_ERROR(cudaFree(d_b));
    CHECK_CUDA_ERROR(cudaFree(d_c));

    return 0;
}

