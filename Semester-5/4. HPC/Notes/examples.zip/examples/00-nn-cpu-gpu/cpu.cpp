﻿#include <iostream>
#include <vector>
#include <cstdlib>
#include <chrono>
#include <algorithm>

// Function for matrix multiplication
void matrixMultiplyCPU(const std::vector<float>& A, const std::vector<float>& B, std::vector<float>& C, int N, int M, int K) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            float sum = 0.0f;
            for (int k = 0; k < M; ++k) {
                sum += A[i * M + k] * B[k * K + j];
            }
            C[i * K + j] = sum;
        }
    }
}

// Function for ReLU activation
void reluActivationCPU(std::vector<float>& A) {
    for (auto& val : A) {
        val = std::max(0.0f, val);
    }
}

int main() {
    // Define dimensions
    int inputSize = 1024;          // Input size (number of features)
    int hiddenSize = 2048;         // Number of neurons in each hidden layer
    int outputSize = 512;          // Output size (number of classes)
    int batchSize = 128;           // Number of samples in a batch
    int numLayers = 5;             // Number of hidden layers

    // Initialize input and weights
    std::vector<float> input(batchSize * inputSize);
    std::vector<std::vector<float>> weights(numLayers);
    std::vector<float> hidden(batchSize * hiddenSize);
    std::vector<float> output(batchSize * outputSize);

    for (int i = 0; i < numLayers; i++) {
        int inputDim = (i == 0) ? inputSize : hiddenSize;
        int outputDim = (i == numLayers - 1) ? outputSize : hiddenSize;
        weights[i].resize(inputDim * outputDim);
        for (auto& val : weights[i]) val = static_cast<float>(rand()) / RAND_MAX;
    }

    // Fill input with random values
    for (auto& val : input) val = static_cast<float>(rand()) / RAND_MAX;

    // Start measuring time
    auto start = std::chrono::high_resolution_clock::now();

    // Forward pass through layers
    for (int i = 0; i < numLayers; i++) {
        int inputDim = (i == 0) ? inputSize : hiddenSize;
        int outputDim = (i == numLayers - 1) ? outputSize : hiddenSize;

        if (i == 0) {
            // First layer: input to hidden
            matrixMultiplyCPU(input, weights[i], hidden, batchSize, inputDim, outputDim);
        } else if (i == numLayers - 1) {
            // Last layer: hidden to output
            matrixMultiplyCPU(hidden, weights[i], output, batchSize, inputDim, outputDim);
        } else {
            // Hidden to hidden
            matrixMultiplyCPU(hidden, weights[i], hidden, batchSize, inputDim, outputDim);
        }

        // Apply ReLU activation (except for the output layer)
        if (i < numLayers - 1) {
            reluActivationCPU(hidden);
        }
    }

    // Stop measuring time
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<float, std::milli> duration = stop - start;

    // Print elapsed time
    std::cout << "Elapsed time: " << duration.count() << " ms\n";

    return 0;
}
