﻿#include <iostream>
#include <vector>
#include <cstdlib>
#include <cuda_runtime.h>

// Kernel for matrix multiplication
__global__ void matrixMultiply(float* A, float* B, float* C, int N, int M, int K) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < N && col < K) {
        float sum = 0.0f;
        for (int i = 0; i < M; i++) {
            sum += A[row * M + i] * B[i * K + col];
        }
        C[row * K + col] = sum;
    }
}

// Kernel for ReLU activation
__global__ void reluActivation(float* A, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        A[idx] = fmaxf(0.0f, A[idx]);
    }
}

// Helper function to allocate and copy data to GPU
float* allocateAndCopyToDevice(const std::vector<float>& hostData) {
    float* deviceData;
    cudaMalloc(&deviceData, hostData.size() * sizeof(float));
    cudaMemcpy(deviceData, hostData.data(), hostData.size() * sizeof(float), cudaMemcpyHostToDevice);
    return deviceData;
}

int main() {
    // Define dimensions
    int inputSize = 1024;          // Input size (number of features)
    int hiddenSize = 2048;         // Number of neurons in each hidden layer
    int outputSize = 512;          // Output size (number of classes)
    int batchSize = 128;           // Number of samples in a batch
    int numLayers = 5;             // Number of hidden layers

    // Initialize input and weights
    std::vector<float> input(batchSize * inputSize);
    std::vector<float> weights[numLayers];
    std::vector<float> biases[numLayers];
    for (int i = 0; i < numLayers; i++) {
        int inputDim = (i == 0) ? inputSize : hiddenSize;
        int outputDim = (i == numLayers - 1) ? outputSize : hiddenSize;
        weights[i] = std::vector<float>(inputDim * outputDim);
        biases[i] = std::vector<float>(outputDim);

        for (auto& val : weights[i]) val = static_cast<float>(rand()) / RAND_MAX;
        for (auto& val : biases[i]) val = static_cast<float>(rand()) / RAND_MAX;
    }

    // Allocate and copy data to GPU
    float* d_input = allocateAndCopyToDevice(input);
    float* d_weights[numLayers];
    float* d_biases[numLayers];
    float* d_hidden;
    float* d_output;

    for (int i = 0; i < numLayers; i++) {
        d_weights[i] = allocateAndCopyToDevice(weights[i]);
        d_biases[i] = allocateAndCopyToDevice(biases[i]);
    }

    cudaMalloc(&d_hidden, batchSize * hiddenSize * sizeof(float));
    cudaMalloc(&d_output, batchSize * outputSize * sizeof(float));

    // Create CUDA events for timing
    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    // Record the start time
    cudaEventRecord(start);

    // Forward pass through layers
    for (int i = 0; i < numLayers; i++) {
        int inputDim = (i == 0) ? inputSize : hiddenSize;
        int outputDim = (i == numLayers - 1) ? outputSize : hiddenSize;
        dim3 blockDim(16, 16);
        dim3 gridDim((outputDim + 15) / 16, (batchSize + 15) / 16);

        // Perform matrix multiplication
        if (i == 0) {
            matrixMultiply<<<gridDim, blockDim>>>(d_input, d_weights[i], d_hidden, batchSize, inputDim, outputDim);
        } else if (i == numLayers - 1) {
            matrixMultiply<<<gridDim, blockDim>>>(d_hidden, d_weights[i], d_output, batchSize, inputDim, outputDim);
        } else {
            matrixMultiply<<<gridDim, blockDim>>>(d_hidden, d_weights[i], d_hidden, batchSize, inputDim, outputDim);
        }

        // Apply ReLU activation (except for the output layer)
        if (i < numLayers - 1) {
            int hiddenElements = batchSize * hiddenSize;
            reluActivation<<<(hiddenElements + 255) / 256, 256>>>(d_hidden, hiddenElements);
        }
    }

    // Record the stop time
    cudaEventRecord(stop);

    // Synchronize events
    cudaEventSynchronize(stop);

    // Calculate elapsed time in milliseconds
    float milliseconds = 0;
    cudaEventElapsedTime(&milliseconds, start, stop);

    // Copy results back to host
    std::vector<float> output(batchSize * outputSize);
    cudaMemcpy(output.data(), d_output, output.size() * sizeof(float), cudaMemcpyDeviceToHost);

    // Print the elapsed time
    std::cout << "Elapsed time: " << milliseconds << " ms\n";

    // Free GPU memory
    cudaFree(d_input);
    for (int i = 0; i < numLayers; i++) {
        cudaFree(d_weights[i]);
        cudaFree(d_biases[i]);
    }
    cudaFree(d_hidden);
    cudaFree(d_output);

    // Destroy CUDA events
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}

