#include <iostream>
#include <cuda.h>
#include <chrono>

#define N (1 << 25)
#define THREADS 256   // Threads per block

// CUDA kernel for vector addition
__global__ void vectorAdd(const float* A, const float* B, float* C, int n) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) {
        C[idx] = A[idx] + B[idx];
    }
}

int main() {
    // ---------------- Host memory ----------------
    float *h_A, *h_B, *h_C;
    h_A = new float[N];
    h_B = new float[N];
    h_C = new float[N];

    // Initialize vectors
    for (int i = 0; i < N; i++) {
        h_A[i] = 1.0f;
        h_B[i] = 2.0f;
    }

    // ---------------- CPU computation ----------------
    auto cpu_start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < N; i++) {
        h_C[i] = h_A[i] + h_B[i];
    }
    auto cpu_end = std::chrono::high_resolution_clock::now();
    double cpu_time = std::chrono::duration<double, std::milli>(cpu_end - cpu_start).count();
    std::cout << "CPU computation time: " << cpu_time << " ms\n";

    // ---------------- Device memory ----------------
    float *d_A, *d_B, *d_C;
    cudaMalloc((void**)&d_A, N * sizeof(float));
    cudaMalloc((void**)&d_B, N * sizeof(float));
    cudaMalloc((void**)&d_C, N * sizeof(float));

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    // ---------------- Copy Host to Device ----------------
    cudaEventRecord(start);
    cudaMemcpy(d_A, h_A, N * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(d_B, h_B, N * sizeof(float), cudaMemcpyHostToDevice);
    cudaEventRecord(stop);
    cudaEventSynchronize(stop);
    float h2d_time = 0;
    cudaEventElapsedTime(&h2d_time, start, stop);
    std::cout << "Host to Device transfer time: " << h2d_time << " ms\n";

    // ---------------- Kernel execution ----------------
    int blocks = (N + THREADS - 1) / THREADS;
    cudaEventRecord(start);
    vectorAdd<<<blocks, THREADS>>>(d_A, d_B, d_C, N);
    cudaEventRecord(stop);
    cudaEventSynchronize(stop);
    float kernel_time = 0;
    cudaEventElapsedTime(&kernel_time, start, stop);
    std::cout << "GPU kernel computation time: " << kernel_time << " ms\n";

    // ---------------- Copy Device to Host ----------------
    cudaEventRecord(start);
    cudaMemcpy(h_C, d_C, N * sizeof(float), cudaMemcpyDeviceToHost);
    cudaEventRecord(stop);
    cudaEventSynchronize(stop);
    float d2h_time = 0;
    cudaEventElapsedTime(&d2h_time, start, stop);
    std::cout << "Device to Host transfer time: " << d2h_time << " ms\n";

    // ---------------- Total GPU time ----------------
    std::cout << "Total GPU time (H2D + Kernel + D2H): " 
              << (h2d_time + kernel_time + d2h_time) << " ms\n";

    // ---------------- Cleanup ----------------
    cudaFree(d_A);
    cudaFree(d_B);
    cudaFree(d_C);
    delete[] h_A;
    delete[] h_B;
    delete[] h_C;

    return 0;
}
