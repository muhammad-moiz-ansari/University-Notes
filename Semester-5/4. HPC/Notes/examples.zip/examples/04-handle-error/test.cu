#include<stdio.h>

static void HandleError( cudaError_t err,
                         const char *file,
                         int line ) {
    if (err != cudaSuccess) {
        printf( "%s in %s at line %d\n", cudaGetErrorString( err ),
                file, line );
        exit( EXIT_FAILURE );
    }
}

#define CU_CALL( err ) (HandleError( err, __FILE__, __LINE__ ))

__global__ void hello()
{
    printf("GPU: Hello. Thread=%d in Block=%d\n",
        threadIdx.x, blockIdx.x);
}

int main(int argc,char **argv)
{
    printf("CPU: Hello!\n");

    hello<<<2,5>>>();
    CU_CALL(cudaGetLastError());
    cudaDeviceSynchronize();
    return 0;
}
